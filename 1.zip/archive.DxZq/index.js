const fs = require('fs');
const moment = require('moment');
const TelegramBot = require('node-telegram-bot-api');
const config = require('./config.json');
const logger = require('./utils/log.js'); // logger by Niiozic

const bot = new TelegramBot(config.token, { polling: config.polling });

const commands = new Map();
const cooldowns = new Map(); 

const loadCommands = () => {
    const commandFiles = fs.readdirSync('./modules').filter(file => file.endsWith('.js'));
    let loadedCommandCount = 0;

    commandFiles.forEach(file => {
        try {
            const command = require(`./modules/${file}`);
            commands.set(command.config.name, command);
            if (command.config.alias && Array.isArray(command.config.alias)) {
                command.config.alias.forEach(alias => commands.set(alias, command));
            }
            loadedCommandCount++;
            logger.loader(`Đã tải lệnh: ${command.config.name}`);
        } catch (error) {
            console.error(`Lỗi khi tải lệnh ${file}:`, error.message);
        }
    });

    logger.loader(`Đã tải thành công ${loadedCommandCount}/${commandFiles.length} lệnh.`);
};

bot.on('polling_error', (error) => console.error('Lỗi khi polling:', error));
bot.getMe().then((me) => {
    logger.loader(`Đăng nhập thành công tại: @${me.username}`);
});

const isAdmin = (userId) => {
    return config.admins.includes(userId); 
};

bot.on('message', (msg) => {
    if (!msg.text || !msg.text.startsWith(config.prefix)) return;

    const args = msg.text.slice(config.prefix.length).trim().split(" ");
    const commandName = args.shift().toLowerCase();
    const userId = msg.from.id;

    if (commands.has(commandName)) {
        const command = commands.get(commandName);

        if (command.config.isAdmin && !isAdmin(userId)) {
            bot.sendMessage(msg.chat.id, "Bạn không có quyền thực hiện lệnh này.");
            return;
        }

        const now = Date.now();
        const cooldownKey = `${commandName}-${userId}`;
        const cooldownAmount = (command.config.cooldowns || 0) * 1000; 
        if (cooldowns.has(cooldownKey)) {
            const expirationTime = cooldowns.get(cooldownKey) + cooldownAmount;
            if (now < expirationTime) {
                const timeLeft = ((expirationTime - now) / 1000).toFixed(1);
                bot.sendMessage(msg.chat.id, `Vui lòng đợi ${timeLeft} giây trước khi sử dụng lại lệnh /${commandName}.`);
                return;
            }
        }

        cooldowns.set(cooldownKey, now);
        try {
            command.run(bot, msg, args, commands); 
        } catch (error) {
            bot.sendMessage(msg.chat.id, "Đã xảy ra lỗi khi thực thi lệnh.");
            console.error(`Lỗi khi thực hiện lệnh ${commandName}:`, error);
        }
    } else {
        bot.sendMessage(msg.chat.id, "Lệnh không tồn tại!");
    }
});

loadCommands();
bot.on('message', (msg) => {
    const chatId = msg.chat.id;

    if (msg.text === '/start') {
        const firstName = msg.from.first_name || '';
        const lastName = msg.from.last_name || '';

        let greetingMessage = '👋🏻 Xin chào ';

        if (firstName && lastName) {
            greetingMessage += `${firstName} ${lastName}`;
        } else if (firstName) {
            greetingMessage += firstName;
        } else if (lastName) {
            greetingMessage += lastName;
        } else {
            greetingMessage += '';
        }

        greetingMessage += '!';
      
        greetingMessage += '\n\n┏━━━━━━━━━━━━━━━┓';
          
        greetingMessage += '\n┃\t\t\t\t\t\t\t\t\t\t\t\𝙈𝘿𝙐𝘾𝙆 𝘽𝙊𝙏';

        greetingMessage += '\n┗━━━━━━━━━━━━━━━┛';
      
        greetingMessage += '\n┏━━━━━━━━━━━━━━━┓';
          
        greetingMessage += '\n┃' +  ' /start' + ' : Khởi động Bot';

        greetingMessage += '\n┃' +  ' /uptime' + ' : Giám sát ';

        greetingMessage += '\n┃' +  ' /help' + ' :  Xem hướng dẫn';
      
        greetingMessage += '\n┗━━━━━━━━━━━━━━━┛\n';

        greetingMessage += '\nChúc bạn sử dụng bot vui vẻ!';
    }
});
bot.on('message', (msg) => {
    const chatId = msg.chat.id;
    const username = msg.from.username || '';
    const fullName = msg.from.first_name ? `${msg.from.first_name} ${msg.from.last_name || ''}` : '';
    const messageId = msg.message_id;
    const messageText = msg.text;

    const now = new Date();
    const vietnamTime = moment.tz('Asia/Ho_Chi_Minh').format('YYYY-MM-DD HH:mm:ss')

    console.log('\n┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n┣➤ Thông tin cuộc trò chuyện ');
    console.log(`┣➤ ${fullName}`);
    console.log(`┣➤ @${username}`);
    console.log(`┣➤ ID : ${chatId}`);
    console.log(`┣➤ Tin nhắn : ${messageText}`);
    console.log(`┣➤ Thời gian : ${vietnamTime}`);
    console.log('┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━➤');
});