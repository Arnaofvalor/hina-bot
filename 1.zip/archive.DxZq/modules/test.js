const axios = require('axios');
const fs = require('fs');
const path = require('path');
const FormData = require('form-data');

module.exports.config = {
  name: "download2",
  description: "Tải ảnh hoặc video từ các nền tảng và gửi lại cho người dùng",
  usage: "/test [link]",
  isAdmin: false,
  credits: "mduc",
  cooldowns: 20
};

module.exports.run = async (bot, msg, args) => {
  const chatId = msg.chat.id;
  const url = args[0];

  if (!url) {
    bot.sendMessage(chatId, "Vui lòng cung cấp một đường link hợp lệ.");
    return;
  }

  if (isValidURL(url)) {
    const apiUrl = `http://dongdev.click/api/down/media?url=${url}`;

    try {
      const response = await axios.get(apiUrl);
      const data = response.data;

      if (data.attachments && data.attachments.length > 0) {
        const attachments = data.attachments;

        if (attachments[0].type === "Photo") {
          await sendPhotos(bot, chatId, attachments);
        } else if (attachments[0].type === "Video") {
          // Tải video và gửi qua TinyURL nếu file quá lớn
          const videoUrl = attachments[0].url;
          await handleLargeVideo(bot, chatId, videoUrl);
        }

        // Gửi thông tin mô tả và thống kê
        const infoMessage = formatInfoMessage(data);
        bot.sendMessage(chatId, infoMessage);
      } else {
        bot.sendMessage(chatId, "Không thể tải nội dung từ liên kết này.");
      }
    } catch (error) {
      console.error(error);
      bot.sendMessage(chatId, "Có lỗi xảy ra khi tải nội dung.");
    }
  } else {
    bot.sendMessage(chatId, "Đường link không hợp lệ.");
  }
};

// Hàm kiểm tra URL hợp lệ
function isValidURL(url) {
  const regex = /(https?:\/\/[^\s]+)/g;
  return regex.test(url);
}

// Hàm gửi ảnh
async function sendPhotos(bot, chatId, attachments) {
  try {
    const photoUrls = attachments.map(attachment => attachment.url);
    for (const url of photoUrls) {
      await bot.sendPhoto(chatId, url);
    }
  } catch (error) {
    console.error("Lỗi khi gửi ảnh:", error);
    bot.sendMessage(chatId, "Có lỗi khi gửi ảnh.");
  }
}

// Hàm xử lý video lớn và gửi qua TinyURL
async function handleLargeVideo(bot, chatId, videoUrl) {
  try {
    // Sử dụng TinyURL API để tạo link rút gọn
    const tinyUrl = await createTinyUrl(videoUrl);

    // Gửi link rút gọn tới người dùng
    bot.sendMessage(chatId, `Video quá lớn để gửi trực tiếp. Bạn có thể tải nó từ đây: ${tinyUrl}`);
  } catch (error) {
    console.error("Lỗi khi tạo TinyURL:", error);
    bot.sendMessage(chatId, "Có lỗi khi tạo link tải video.");
  }
}

// Hàm tạo TinyURL
async function createTinyUrl(videoUrl) {
  try {
    const response = await axios.get(`https://tinyurl.com/api-create.php?url=${videoUrl}`);
    return response.data; // Trả về link rút gọn
  } catch (error) {
    console.error("Lỗi khi tạo TinyURL:", error);
    throw error;
  }
}

// Hàm định dạng tin nhắn thông tin
function formatInfoMessage(data) {
  const { id, message, author, stats, createTime, music } = data;
  const infoMessage = `
    ID: ${id}
    Mô tả: ${message}
    Tác giả: ${author.name} (@${author.username})
    Lượt xem: ${stats.views}, Lượt thích: ${stats.likes}
    Bình luận: ${stats.comments}, Chia sẻ: ${stats.shares}
    Nhạc: ${music.title} - ${music.author}
    Thời gian tạo: ${createTime}
  `;
  return infoMessage.trim();
}