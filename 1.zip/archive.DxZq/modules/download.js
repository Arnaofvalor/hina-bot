const axios = require('axios');

module.exports.config = {
  name: "download",
  description: "Tải video từ các nền tảng bằng cách gửi link.",
  usage: "/download [link]",
  isAdmin: false,
  credits: "hmhung",
  cooldowns: 20
};

module.exports.run = async (bot, msg, args) => {
  const chatId = msg.chat.id;
  const videoUrl = args[0]; // URL từ người dùng

  // Kiểm tra nếu không có URL
  if (!videoUrl) {
    return bot.sendMessage(chatId, "Vui lòng gửi một đường link hợp lệ.");
  }

  // Gửi thông báo rằng bot đang xử lý yêu cầu
  bot.sendMessage(chatId, "Đang xử lý video, vui lòng chờ...");

  try {
    // Gửi yêu cầu đến API để tải video
    const response = await axios.get(`https://api-c2c.onrender.com/api/down/media?url=${videoUrl}&format=json`);

    // Kiểm tra nếu API trả về thành công
    if (response.data && response.data.attachments && response.data.attachments.length > 0) {
      const videoData = response.data.attachments[0]; // Lấy dữ liệu video đầu tiên
      const mediaUrl = videoData.url;
      const audioUrl = response.data.audio;
      const authorName = response.data.author.name;
      const message = response.data.message;
      const statistics = response.data.statistics;

      // Gửi thông tin về video
      let infoMessage = `💡 **Thông tin video**\n`;
      infoMessage += `👤 Tác giả: ${authorName}\n`;
      infoMessage += `💬 Mô tả: ${message}\n`;
      infoMessage += `👍 Lượt thích: ${statistics.like}\n`;
      infoMessage += `💬 Bình luận: ${statistics.comment}\n`;
      infoMessage += `🔄 Chia sẻ: ${statistics.share}\n`;

      bot.sendMessage(chatId, infoMessage);

      // Gửi video về cho người dùng
      bot.sendVideo(chatId, mediaUrl, {
        caption: `🎬 Video tải từ: ${authorName}`
      });

      // Gửi audio nếu có
      if (audioUrl) {
        bot.sendAudio(chatId, audioUrl, {
          caption: `🎵 Âm thanh từ video`
        });
      }

    } else {
      bot.sendMessage(chatId, 'Không thể tải video. Vui lòng kiểm tra lại đường link.');
    }
  } catch (error) {
    console.error('Lỗi khi tải video:', error);
    bot.sendMessage(chatId, 'Có lỗi xảy ra khi xử lý yêu cầu của bạn. Vui lòng thử lại sau.');
  }
};