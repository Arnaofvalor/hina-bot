const axios = require('axios');
const fs = require('fs');
const path = require('path');
const FormData = require('form-data');

module.exports.config = {
  name: "download1",
  description: "Tải ảnh hoặc video từ các nền tảng và gửi lại cho người dùng(đang trong quá trình thử nghiệm)",
  usage: "/download1 [link]",
  isAdmin: false,
  credits: "mduc",
  cooldowns: 20
};

module.exports.run = async (bot, msg, args) => {
  const chatId = msg.chat.id;
  const url = args[0];

  if (!url) {
    bot.sendMessage(chatId, "Vui lòng cung cấp một đường link hợp lệ.");
    return;
  }

  if (isValidURL(url)) {
    const apiUrl = `http://dongdev.click/api/down/media?url=${url}`;

    try {
      const response = await axios.get(apiUrl);
      const data = response.data;

      if (data.attachments && data.attachments.length > 0) {
        const attachments = data.attachments;

        if (attachments[0].type === "Photo") {
          await sendPhotos(bot, chatId, attachments);
        } else if (attachments[0].type === "Video") {
          // Tải video và kiểm tra dung lượng
          const videoUrl = attachments[0].url;
          await handleVideo(bot, chatId, videoUrl);
        }

        // Gửi thông tin mô tả và thống kê
        const infoMessage = formatInfoMessage(data);
        bot.sendMessage(chatId, infoMessage);
      } else {
        bot.sendMessage(chatId, "Không thể tải nội dung từ liên kết này.");
      }
    } catch (error) {
      console.error(error);
      bot.sendMessage(chatId, "Có lỗi xảy ra khi tải nội dung.");
    }
  } else {
    bot.sendMessage(chatId, "Đường link không hợp lệ.");
  }
};

// Hàm kiểm tra URL hợp lệ
function isValidURL(url) {
  const regex = /(https?:\/\/[^\s]+)/g;
  return regex.test(url);
}

// Hàm gửi ảnh
async function sendPhotos(bot, chatId, attachments) {
  try {
    const photoUrls = attachments.map(attachment => attachment.url);
    for (const url of photoUrls) {
      await bot.sendPhoto(chatId, url);
    }
  } catch (error) {
    console.error("Lỗi khi gửi ảnh:", error);
    bot.sendMessage(chatId, "Có lỗi khi gửi ảnh.");
  }
}

// Hàm xử lý video
async function handleVideo(bot, chatId, videoUrl) {
  try {
    // Tải video tạm thời về
    const videoPath = await downloadVideo(videoUrl);

    // Kiểm tra dung lượng video
    const fileSizeInMB = getFileSizeInMB(videoPath);
    
    if (fileSizeInMB > 50) {
      // Sử dụng TinyURL nếu video lớn hơn 50MB
      const tinyUrl = await createTinyUrl(videoUrl);
      bot.sendMessage(chatId, `Video quá lớn để gửi trực tiếp. Bạn có thể tải nó từ đây: ${tinyUrl}`);
    } else {
      // Gửi video trực tiếp nếu dung lượng dưới 50MB
      await bot.sendVideo(chatId, videoPath);
    }

    // Xóa video tạm sau khi xử lý xong
    fs.unlinkSync(videoPath);
  } catch (error) {
    console.error("Lỗi khi xử lý video:", error);
    bot.sendMessage(chatId, "Có lỗi khi xử lý video.");
  }
}

// Hàm tải video tạm thời về máy
async function downloadVideo(url) {
  const videoPath = path.join(__dirname, 'temp_video.mp4');
  const response = await axios({
    url,
    method: 'GET',
    responseType: 'stream',
  });
  const writer = fs.createWriteStream(videoPath);

  response.data.pipe(writer);

  return new Promise((resolve, reject) => {
    writer.on('finish', () => resolve(videoPath));
    writer.on('error', reject);
  });
}

// Hàm tính dung lượng file
function getFileSizeInMB(filePath) {
  const stats = fs.statSync(filePath);
  const fileSizeInBytes = stats.size;
  return fileSizeInBytes / (1024 * 1024); // Chuyển đổi sang MB
}

// Hàm tạo TinyURL
async function createTinyUrl(videoUrl) {
  try {
    const response = await axios.get(`https://tinyurl.com/api-create.php?url=${videoUrl}`);
    return response.data; // Trả về link rút gọn
  } catch (error) {
    console.error("Lỗi khi tạo TinyURL:", error);
    throw error;
  }
}

// Hàm định dạng tin nhắn thông tin
function formatInfoMessage(data) {
  const { id, message, author, stats, createTime, music } = data;
  const infoMessage = `
    ID: ${id}
    Mô tả: ${message}
    Tác giả: ${author.name} (@${author.username})
    Lượt xem: ${stats.views}, Lượt thích: ${stats.likes}
    Bình luận: ${stats.comments}, Chia sẻ: ${stats.shares}
    Nhạc: ${music.title} - ${music.author}
    Thời gian tạo: ${createTime}
  `;
  return infoMessage.trim();
}